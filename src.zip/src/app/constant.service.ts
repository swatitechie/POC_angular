import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConstantService {
//url is a variable which stores constand url
  public url : string = "https://newitexdev.accenture.com/";
  
  constructor() { }
  


}
